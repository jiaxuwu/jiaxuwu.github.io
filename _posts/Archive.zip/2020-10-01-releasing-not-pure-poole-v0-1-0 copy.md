---
layout: post
title: Releasing Not Pure Poole v0.1.0
author: Songzi Vong
tags:
- jekyll theme
- jekyll
date: 2020-10-01 13:56 +0800
---
The Jekyll theme **Not Pure Poole** v0.1.0 was released!

Not Pure Poole is a simple, beautiful, and powerful Jekyll theme for blogs. It is built on [Poole](https://github.com/poole/poole) and [Pure](https://purecss.io/).

For more information about this theme, you can read the [README](https://github.com/vszhub/not-pure-poole/blob/master/README.md) file.
